# Movement Masters
## How to set up
Extract the zip file into a folder. The files should all be set up and work from the start. settings.py and sprites.py need to be in the same folder as each other. Then just run the game. Be warned that a deathleft or deathright will spawn immediately, so you should be alert straight away.
## Goal
You need to survive for as long as you can. Using a working highscore. The highscore will only be uploaded to github when I change other things aswell. Remember that the game gets harder every time you restart. You can press 'r' to manually restart.
## Current Highscore
3333.3 seconds - Set by Carthiga Bell
